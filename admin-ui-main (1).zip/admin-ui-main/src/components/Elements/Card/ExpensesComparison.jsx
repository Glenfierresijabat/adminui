import React from "react";

const ExpensesComparison = () => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md mt-3">
      <p className="text-gray-700">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque
        quam alias enim ullam deserunt ducimus consequatur cumque hic voluptatem
        totam ab quibusdam facilis distinctio ratione, sequi vel porro eum.
      </p>
    </div>
  );
};

export default ExpensesComparison;
