import React from "react";

const ExpensesBreakdown = () => {
  return (
    <div className="grid grid-cols-2 gap-4 mt-3">
      <div className="bg-white p-4 rounded-lg shadow-md">
        <p className="text-gray-700">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque quam alias.
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md">
        <p className="text-gray-700">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque quam alias.
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md">
        <p className="text-gray-700">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque quam alias.
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md">
        <p className="text-gray-700">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque quam alias.
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md">
        <p className="text-gray-700">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque quam alias.
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md">
        <p className="text-gray-700">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni neque quam alias.
        </p>
      </div>
    </div>
  );
};

export default ExpensesBreakdown;
